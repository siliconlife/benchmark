#!/bin/bash

# 刷新 sudo 时间戳，确保后续的 sudo 命令不需要再次输入密码
sudo -v

# 安装必要的开发包
sudo apt install -y libx11-dev libgl1-mesa-dev libglu1-mesa-dev freeglut3-dev

# 编译项目
make -j$(nproc)

# 清理缓存
sudo sh -c 'echo 3 > /proc/sys/vm/drop_caches'

# 运行图形程序
vblank_mode=0 ./Run graphics