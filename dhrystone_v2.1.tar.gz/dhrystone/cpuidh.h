
#ifdef __cplusplus
extern "C" {
#endif

extern char    configdata[10][200];
extern char    timeday[30];
extern double  theseSecs;
extern double  startSecs;
extern double  secs;
extern unsigned int millisecs;
extern  double ramGB;
extern  int    megaHz;
extern int     pagesize;
extern int     CPUconf;
extern int     CPUavail;

extern  int     hasMMX;
extern  int     hasSSE;
extern  int     hasSSE2;
extern  int     hasSSE3;
extern  int     has3DNow;

#ifdef __cplusplus
};
#endif
